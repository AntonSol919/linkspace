# Linkspace - POC

This package contains the CLI, Python library, and examples for a domain app and a group exchange process.
If you open python 3.11 in this directory you can use ```import lkpy``` (The lkpy.so file)
Or do ```source ./activate``` to use the `lk` cli

These allow you to follow along with the [Guide](https://antonsol919.github.io/linkspace/docs/guide/index.html) or to build something yourself.
