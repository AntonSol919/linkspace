Anyhost is a trivial client & server using socat.
