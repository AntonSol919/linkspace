# Examples

This folder contains examples that come packaged the necessary stuff to follow along with the guide,
as well as various poc apps and an exchange.

If you got this as a [pkg](https://antonsol919.github.io/linkspace/download.html) it comes bundled with the cli and python module.

Try and say hi by opening two shells:

In the first connect to a server.

```bash
./test-exchange
```

In the second run

```bash
source ./common
linkmail.py
```
